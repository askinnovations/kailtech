export default {
    "tailwindFunctions": ["clsx", "cn"],
    "tailwindAttributes": ["rootClass", "classNames"],
    "plugins": [
        "prettier-plugin-tailwindcss"
    ],
}
