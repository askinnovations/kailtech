import { dashboards } from "./dashboards";


export const navigation = [
    dashboards,
]

export { baseNavigation } from './baseNavigation'
