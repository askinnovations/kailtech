export function Divider() {
  return <div className="my-2.5 h-px bg-gray-200 dark:bg-dark-500" />;
}
